// Vercel serverless function — deployed automatically at /api/generate
// because this file lives in the /api folder. Holds the Anthropic API key
// as a server-side environment variable; the browser never sees it.

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    res.status(405).json({ error: 'Only POST is supported.' });
    return;
  }

  const body = req.body || {};
  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    res.status(400).json({ error: 'Request must include a non-empty messages array.' });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: 'Server is missing the ANTHROPIC_API_KEY environment variable.' });
    return;
  }

  // Rebuilt server-side rather than forwarded verbatim — keeps the model
  // fixed and caps token usage regardless of what the client sends.
  const payload = {
    model: 'claude-sonnet-4-6',
    max_tokens: Math.min(Number(body.max_tokens) || 1000, 2000),
    messages: body.messages
  };
  if (typeof body.system === 'string' && body.system.trim()) {
    payload.system = body.system;
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(payload)
    });
    const text = await upstream.text();
    res.status(upstream.status).setHeader('Content-Type', 'application/json').send(text);
  } catch (e) {
    res.status(502).json({ error: "Could not reach Anthropic's API." });
  }
};
