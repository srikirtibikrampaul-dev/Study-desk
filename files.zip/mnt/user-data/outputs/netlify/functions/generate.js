// Netlify Function — same job as api/generate.js, written for Netlify's
// handler signature. netlify.toml redirects /api/generate here so the
// front end can call the same "/api/generate" path on either host.

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Only POST is supported.' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body.' }) };
  }

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Request must include a non-empty messages array.' }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Server is missing the ANTHROPIC_API_KEY environment variable.' }) };
  }

  const payload = {
    model: 'claude-sonnet-4-6',
    max_tokens: Math.min(Number(body.max_tokens) || 1000, 2000),
    messages: body.messages
  };
  if (typeof body.system === 'string' && body.system.trim()) {
    payload.system = body.system;
  }

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(payload)
    });
    const text = await upstream.text();
    return { statusCode: upstream.status, headers: { 'Content-Type': 'application/json' }, body: text };
  } catch (e) {
    return { statusCode: 502, body: JSON.stringify({ error: "Could not reach Anthropic's API." }) };
  }
};
