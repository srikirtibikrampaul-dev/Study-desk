# Deploying Study Desk with a working, non-exposed API

`index.html` never talks to Anthropic directly once this is deployed. It
calls `/api/generate` on your own site, and a serverless function there
holds the real API key as a server-side environment variable — the key
never reaches the browser and never lives in your GitHub repo.

The project already contains both options; pick ONE host:

```
project/
├── index.html                     ← the site
├── api/generate.js                ← used by Vercel
├── netlify/functions/generate.js  ← used by Netlify
├── netlify.toml                   ← only needed for Netlify
└── package.json
```

You don't need to delete the files for the host you're not using — Vercel
ignores the `netlify/` folder and vice versa.

## 1. Get an Anthropic API key

https://console.anthropic.com → **API Keys** → create a new key. Copy it
somewhere safe; you won't see it again.

## 2. Push the whole project folder to GitHub

Create a new repo on github.com, then upload the entire `project/` folder
contents (not just `index.html` this time — the `api/` or `netlify/`
folder needs to be in the repo too, since that's what Vercel/Netlify
deploys). Uploading via the GitHub web UI's "uploading an existing file"
works fine for this; drag the whole folder's contents in at once.

## 3A. Deploy on Vercel

1. Go to https://vercel.com, sign up/log in with GitHub.
2. Click **Add New → Project**, pick your repo.
3. Leave the build settings as default — Vercel auto-detects the `api/`
   folder as serverless functions and serves `index.html` as-is.
4. Before deploying, open **Environment Variables** and add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your Anthropic key
5. Click **Deploy**. You'll get a live URL like
   `https://study-desk.vercel.app` — open it and try generating a study
   pack for real.

## 3B. Deploy on Netlify (instead of Vercel)

1. Go to https://app.netlify.com, sign up/log in with GitHub.
2. **Add new site → Import an existing project**, pick your repo.
3. Netlify reads `netlify.toml` automatically, which points it at
   `netlify/functions` and redirects `/api/*` there.
4. Go to **Site configuration → Environment variables**, add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your Anthropic key
5. Click **Deploy site**. You'll get a live URL like
   `https://study-desk.netlify.app`.

## 4. Redeploy after any future edits

Both Vercel and Netlify auto-redeploy whenever you push new commits to the
connected GitHub repo — no manual re-upload needed after the first setup.

## Why this actually fixes the security problem

- The API key lives only in Vercel's/Netlify's environment variable
  storage — never in your HTML, never in your repo, never visible to
  anyone opening your site or viewing its source.
- The browser only ever calls your own `/api/generate` route, which is
  same-origin, so there's no CORS issue.
- `api/generate.js` / `netlify/functions/generate.js` rebuild the request
  to Anthropic themselves (fixed model, capped `max_tokens`), so even a
  malicious visitor poking at your endpoint can't run up unbounded usage
  or swap in a different model.

## Costs

Both Vercel's and Netlify's free tiers comfortably cover a hackathon demo.
You still pay Anthropic for actual API usage — keep an eye on usage in the
Anthropic console if you share the live link widely, since anyone with the
link can trigger a generation.

## UI / styling (separate from all of the above)

Everything above is about hosting and security; it doesn't touch how the
site looks. If you want to iterate on the design, that's just editing the
CSS inside the `<style>` block in `index.html` — spacing, colors, and
responsive breakpoints are all in there and don't affect any of the
deployment steps. Happy to help with that separately if you want it.
